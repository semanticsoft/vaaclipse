/**
 * 
 */
package org.semanticsoft.vaaclipsedemo.cassandra.app.constants;

/**
 * @author rushan
 *
 */
public class CassandraConstants
{
	public static final String CONSOLE_LOG = "CONSOLE_LOG";
	public static final String LINK_WITH_EDITOR = "LINK_WITH_EDITOR";
	public static final String COLLAPSE_ALL = "COLLAPSE_ALL";
}
